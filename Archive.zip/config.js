const domain = 'http://103.176.79.148:3041'; // http://167.86.109.232:3041 | http://localhost:3041
const mainDomain = 'https://mongo.animeyusha.com'; // Main Domain Api Softkomik
const copyDomain = 'https://mongo.animeyusha.com'; //// http://localhost:3011

//
// const mainDomain = "http://localhost:3011";
// const copyDomain = "http://localhost:3011";

module.exports = { domain, mainDomain, copyDomain };
